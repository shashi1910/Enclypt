package com.example.lab5

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.lab5.ui.theme.Lab5Theme
import kotlinx.serialization.Serializable


val Password_2_off: ImageVector
    get() {
        if (_Password_2_off != null) {
            return _Password_2_off!!
        }
        _Password_2_off = ImageVector.Builder(
            name = "Password_2_off",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 960f,
            viewportHeight = 960f
        ).apply {
            path(
                fill = SolidColor(Color.Black),
                fillAlpha = 1.0f,
                stroke = null,
                strokeAlpha = 1.0f,
                strokeLineWidth = 1.0f,
                strokeLineCap = StrokeCap.Butt,
                strokeLineJoin = StrokeJoin.Miter,
                strokeLineMiter = 1.0f,
                pathFillType = PathFillType.NonZero
            ) {
                moveTo(160f, 520f)
                quadToRelative(-50f, 0f, -85f, -35f)
                reflectiveQuadToRelative(-35f, -85f)
                reflectiveQuadToRelative(35f, -85f)
                reflectiveQuadToRelative(85f, -35f)
                reflectiveQuadToRelative(85f, 35f)
                reflectiveQuadToRelative(35f, 85f)
                reflectiveQuadToRelative(-35f, 85f)
                reflectiveQuadToRelative(-85f, 35f)
                moveToRelative(640f, 0f)
                quadToRelative(-50f, 0f, -85f, -35f)
                reflectiveQuadToRelative(-35f, -85f)
                reflectiveQuadToRelative(35f, -85f)
                reflectiveQuadToRelative(85f, -35f)
                reflectiveQuadToRelative(85f, 35f)
                reflectiveQuadToRelative(35f, 85f)
                reflectiveQuadToRelative(-35f, 85f)
                reflectiveQuadToRelative(-85f, 35f)
                moveToRelative(-220f, -54f)
                lineTo(414f, 300f)
                quadToRelative(14f, -10f, 31f, -15f)
                reflectiveQuadToRelative(35f, -5f)
                quadToRelative(50f, 0f, 85f, 35f)
                reflectiveQuadToRelative(35f, 85f)
                quadToRelative(0f, 18f, -5f, 35f)
                reflectiveQuadToRelative(-15f, 31f)
                moveTo(792f, 904f)
                lineTo(648f, 760f)
                horizontalLineTo(80f)
                verticalLineToRelative(-80f)
                horizontalLineToRelative(488f)
                lineTo(56f, 168f)
                lineToRelative(56f, -56f)
                lineToRelative(736f, 736f)
                close()
            }
        }.build()
        return _Password_2_off!!
    }

private var _Password_2_off: ImageVector? = null

 val Password_2: ImageVector
    get() {
        if (_Password_2 != null) {
            return _Password_2!!
        }
        _Password_2 = ImageVector.Builder(
            name = "Password_2",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 960f,
            viewportHeight = 960f
        ).apply {
            path(
                fill = SolidColor(Color.Black),
                fillAlpha = 1.0f,
                stroke = null,
                strokeAlpha = 1.0f,
                strokeLineWidth = 1.0f,
                strokeLineCap = StrokeCap.Butt,
                strokeLineJoin = StrokeJoin.Miter,
                strokeLineMiter = 1.0f,
                pathFillType = PathFillType.NonZero
            ) {
                moveTo(160f, 520f)
                quadToRelative(-50f, 0f, -85f, -35f)
                reflectiveQuadToRelative(-35f, -85f)
                reflectiveQuadToRelative(35f, -85f)
                reflectiveQuadToRelative(85f, -35f)
                reflectiveQuadToRelative(85f, 35f)
                reflectiveQuadToRelative(35f, 85f)
                reflectiveQuadToRelative(-35f, 85f)
                reflectiveQuadToRelative(-85f, 35f)
                moveTo(80f, 760f)
                verticalLineToRelative(-80f)
                horizontalLineToRelative(800f)
                verticalLineToRelative(80f)
                close()
                moveToRelative(400f, -240f)
                quadToRelative(-50f, 0f, -85f, -35f)
                reflectiveQuadToRelative(-35f, -85f)
                reflectiveQuadToRelative(35f, -85f)
                reflectiveQuadToRelative(85f, -35f)
                reflectiveQuadToRelative(85f, 35f)
                reflectiveQuadToRelative(35f, 85f)
                reflectiveQuadToRelative(-35f, 85f)
                reflectiveQuadToRelative(-85f, 35f)
                moveToRelative(320f, 0f)
                quadToRelative(-50f, 0f, -85f, -35f)
                reflectiveQuadToRelative(-35f, -85f)
                reflectiveQuadToRelative(35f, -85f)
                reflectiveQuadToRelative(85f, -35f)
                reflectiveQuadToRelative(85f, 35f)
                reflectiveQuadToRelative(35f, 85f)
                reflectiveQuadToRelative(-35f, 85f)
                reflectiveQuadToRelative(-85f, 35f)
            }
        }.build()
        return _Password_2!!
    }

private var _Password_2: ImageVector? = null


class MainActivity : ComponentActivity() {
    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Lab5Theme{
                val controller = rememberNavController()
                Scaffold {
                    NavHost(
                        navController = controller,
                        startDestination = Home
                    ) {
                        composable<Home> {
                            FirstScreen(Modifier.fillMaxSize(), controller = controller)
                        }
                        composable<Second> {
                            val args = it.toRoute<Second>()
                            SecondScreen(Modifier.fillMaxSize(),controller,args.name,args.password,args.gender)
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun FirstScreen(modifier: Modifier = Modifier,controller: NavController){
        var name by rememberSaveable { mutableStateOf("") }
        var age by rememberSaveable { mutableStateOf("") }
        val context = LocalContext.current
    var selectedOption by rememberSaveable { mutableStateOf(0) }
    val gen = listOf(
        "Male",
        "Female"
    )
    val cur = listOf(
        "USD",
        "RS",
        "EURO"
    )
    var isPasswordVisible by rememberSaveable { mutableStateOf(false) }
        Column(
            modifier = modifier,
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = name,
                onValueChange = {name = it},
                label = { Text("Username")}
            )
            Spacer(Modifier.height(30.dp))
            OutlinedTextField(
                value = age,
                onValueChange = {age = it},
                visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                label = { Text("Password")},
                trailingIcon = {
                    IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                        Icon(
                            imageVector = if (isPasswordVisible) Password_2_off else Password_2,
                            contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                        )
                    }
                }
            )
            Spacer(Modifier.height(30.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                gen.forEachIndexed { index, s ->
                    RadioButton(
                        onClick = { selectedOption = index },
                        selected = selectedOption == index
                    )
                    Text(
                        text = s
                    )
                }
            }
            Spacer(Modifier.height(30.dp))
            
            OutlinedButton(
                shape = RoundedCornerShape(20),
                onClick = {
                if (!(name.isBlank() && age.isBlank() ))
                { controller.navigate(
                        Second(
                            name,
                            age,
                            gen.get(selectedOption)
                        )
                    )
                }else
                {
                    Toast.makeText(context,"Please fill both the fields",Toast.LENGTH_SHORT).show()
                }
            }) {
                Text(
                    text = "Submit",
                    fontSize = 25.sp
                )
            }
        }
}




@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun SecondScreen(modifier: Modifier = Modifier,controller: NavController,name : String,age : String,gender : String){

//    val items = listOf(
//        navi("Home",Icons.Default.Home ),
//        navi("Profile",Icons.Filled.Person ),
//        navi("Setting",Icons.Default.Settings ),
//
//    )

    Scaffold (
        topBar = {
            TopAppBar(
                title = { Text("Details")},
                navigationIcon = {
                    IconButton(onClick = {
                        controller.popBackStack()
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Localized description"
                        )
                    }
                }
            )
        },

    ){
        Column(
            modifier,
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Name : $name\nPassword : $age\nGender : $gender")
        }
    }
}


//@Composable
//fun Settings(modifier: Modifier = Modifier){
//    Column(modifier, verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
//        Text("Hello this is settings screen")
//    }
//}

//@Composable
//fun Profile(modifier: Modifier = Modifier){
//    Column(modifier, verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
//        Text("Hello this is profile screen")
//    }
//}





@Serializable
data class Second(
    val name : String,
    val password : String,
    val gender : String,
)

@Serializable
object Home

//@Serializable
//object Settings

//@Serializable
//object Profile
//
//data class navi(
//    val name : String,
//    val  icon : ImageVector
//)




